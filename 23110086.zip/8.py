x = int(input())
res = x**8 - 5 + abs(x)
print(res)