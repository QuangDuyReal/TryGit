num = int(input())
print(num - 1, num + 1)