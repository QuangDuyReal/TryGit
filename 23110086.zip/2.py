a = int(input("Nhap so dau tien: "))
b = int(input("Nhap so thu hai: "))
c = int(input("Nhap so thu ba: "))
average = (a + b + c)/3
print(average)
