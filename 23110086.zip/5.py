a = input()
b = input()
a, b = b, a
print(a, b)