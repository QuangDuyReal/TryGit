n = int(input())
for i in range(10):
    print(n*(i + 1))