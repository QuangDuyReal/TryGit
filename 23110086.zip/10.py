c = input()
print(c)